const $ = id => document.getElementById(id);
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const clone = value => JSON.parse(JSON.stringify(value));
const storageKey = 'pcg-persistent-experiment-design-v1';
const arrow = '<svg viewBox="0 0 30 20" aria-hidden="true"><path d="M0 10H28m-6-5 6 5-6 5"/></svg>';
const inputNames = {case_01_fixture:'Case 01',case_02_fixture:'Case 02',case_03_fixture:'Case 03',alias_merge:'Alias merge',alias_distinct:'Alias distinct'};
const initialDraft = () => ({input:'case_03_fixture',mode:'saved',resolver:false,model:'deepseek-flash'});
function newWorkspace(name) { return {id:crypto.randomUUID(),name,draft:initialDraft(),runs:[],selected:null,plan:null}; }
function fixtureFor(config, freshIndex=0) {
  const id = config.mode === 'fresh' ? `fresh_0${freshIndex%5+1}` : config.input;
  return pilot.samples.find(sample => sample.id === id);
}
function fixtureObservation(run) { return fixtureFor(run.config,run.freshIndex).observations.find(o => run.config.resolver ? o.repetition === run.recordedRepetition : o.repetition === null); }
function configEqual(a,b) { return JSON.stringify(a) === JSON.stringify(b); }
function snapshotRun(workspace,config) {
  const freshIndex=workspace.runs.filter(r=>r.config.mode==='fresh').length;
  const sample=fixtureFor(config,freshIndex);
  return {id:crypto.randomUUID(),number:workspace.runs.length+1,config:clone(config),freshIndex,
    recordedRepetition:1+workspace.runs.filter(r=>r.config.resolver).length%3,
    inputId:sample.id,inputDigest:sample.extraction_digest,sourceDigest:sample.source_digest,
    code:'051e2b08166584c7372626dcd8b02c09fbd075af',planDigest:'demo-'+crypto.randomUUID(),
    createdAt:new Date().toISOString(),status:'frozen',authorization:false,attempts:0,uncertain:0};
}
function initialStore() {
  const workspace=newWorkspace('Does alias resolution improve identity consistency?');
  const run=snapshotRun(workspace,workspace.draft);run.status='completed';run.seeded=true;
  workspace.runs.push(run);workspace.selected=run.id;
  return {experiments:[workspace],current:workspace.id,taskUsed:0,taskAllowance:10};
}
let store;
try {store=JSON.parse(localStorage.getItem(storageKey));} catch {store=null;}
if(!store?.experiments?.length) store=initialStore();
let view='run',costBasis='runCost',filter='all',outcome='matched',relationship=null,expandedNode=null,renameMode=false,showRecord=false;
const current = () => store.experiments.find(e=>e.id===store.current);
const persist = () => localStorage.setItem(storageKey,JSON.stringify(store));
const runName = run => `Run ${String(run.number).padStart(2,'0')}`;
const strategy = config => config.resolver?'Generative resolver':'No resolver';
const inputLabel = config => `${inputNames[config.input]} · ${config.mode==='saved'?'saved extraction':'fresh extraction'}`;
const calls = config => Number(config.mode==='fresh')+Number(config.resolver);
const activeRun = () => store.experiments.flatMap(e=>e.runs).find(r=>['running','stopping'].includes(r.status));
const selectedRun = () => current().runs.find(r=>r.id===current().selected);
const fmt = value => value == null?'Unavailable':value.toFixed(3);
const dollars = value => value == null?'Unavailable':`$${value.toFixed(8)}`;
function runCosts(run) {
  const observation=fixtureObservation(run);
  return {runCost:run.config.mode==='saved'?observation.incremental_cost:observation.full_cost,fullCost:observation.full_cost};
}
function visibleRuns() { return current().runs.filter(r=>filter==='all'||r.config.mode===filter); }
function announce(text) { $('announcement').textContent=text; }
function restoreFocus(attribute,value) {
  [...document.querySelectorAll(`[${attribute}]`)].find(el=>el.getAttribute(attribute)===value)?.focus({preventScroll:true});
}
function selectRun(id) {
  current().selected=id;outcome='matched';relationship=null;showRecord=false;persist();renderChart();renderInspection();
  announce(`${runName(selectedRun())} selected. Its frozen configuration is below. Your next-run draft is unchanged.`);
}
function editDraft(change) {
  const experiment=current();
  if(experiment.plan&&experiment.plan.stage!=='review') return;
  experiment.draft={...experiment.draft,...change};
  if(experiment.draft.mode==='fresh') experiment.draft.input='case_03_fixture';
  if(experiment.plan) experiment.plan=null;
  persist();renderDraft();renderExecution();
  announce('Next-run draft updated. Previous runs and the selected result are unchanged.');
}
function renderHistory() {
  $('experimentTitle').textContent=current().name;
  const completed=current().runs.filter(r=>r.status==='completed').length;
  $('experimentMeta').textContent=`${current().runs.length} run${current().runs.length===1?'':'s'} · ${completed} completed`;
  $('experiments').innerHTML=store.experiments.map(e=>`<button class="history-item ${e.id===store.current?'active':''}" data-experiment="${e.id}" aria-current="${e.id===store.current?'page':'false'}"><b>${escapeHtml(e.name)}</b><span>${e.runs.length} run${e.runs.length===1?'':'s'} · ${e.runs.filter(r=>r.status==='completed').length} completed</span></button>`).join('');
}
function renderDraft() {
  const experiment=current(),config=experiment.draft,last=experiment.runs.at(-1),locked=experiment.plan&&experiment.plan.stage!=='review';
  const changed=last&&!configEqual(config,last.config),active=activeRun();
  $('draftStatus').textContent=locked?'Frozen plan':changed?'Configuration changed':'Ready';
  $('run').disabled=!!locked||!!active||calls(config)>store.taskAllowance-store.taskUsed;
  $('run').textContent=active?'Run active':locked?'Plan frozen':'Run';
  $('benchmark').innerHTML=Object.entries(inputNames).map(([id,name])=>`<option value="${id}">${name}</option>`).join('');
  $('benchmark').value=config.input;$('benchmark').disabled=!!locked||config.mode==='fresh';
  $('inputMode').value=config.mode;$('inputMode').disabled=!!locked;
  $('inputIdentity').textContent=config.mode==='saved'?`${config.input} · frozen extraction reused`:'A new extraction identity for this run · Case 03 in this study';
  const settings=(id,content)=>`<div class="node-settings" ${expandedNode===id?'':'hidden'}>${content}</div>`;
  $('pipeline').innerHTML=`<article class="node"><div class="node-head"><b>Extract relationships</b></div><span>Model · Required for source</span><p>${config.mode==='saved'?'Bypassed · saved extraction':'New extraction · deepseek-flash'}</p><button data-settings="extract" class="node-title">${expandedNode==='extract'?'Collapse settings':'Expand settings'}</button>${settings('extract',`<label>Model<select disabled><option>deepseek-flash</option></select></label><small>Shared model for this draft. Saved mode reuses the selected extraction.</small>`)}</article><div class="connector">${arrow}${!config.resolver?`<button id="addResolver" ${locked?'disabled':''} aria-label="Add generative resolver"><span>+</span></button>`:''}</div>${config.resolver?`<article class="node resolver"><div class="node-head"><b>Resolve aliases</b><button class="remove" id="removeResolver" ${locked?'disabled':''} aria-label="Remove resolver from next-run draft">×</button></div><span>Model · Optional</span><p>Generative · full-source</p><button data-settings="resolver" class="node-title">${expandedNode==='resolver'?'Collapse settings':'Expand settings'}</button>${settings('resolver','<p>One resolution invocation in this run.</p><small>Repeated executions become separate runs. Prior results stay immutable.</small>')}</article><div class="connector">${arrow}</div>`:''}<article class="node"><div class="node-head"><b>Build relationship graph</b></div><span>Deterministic · Required</span><p>Fixed validation + construction</p><button data-settings="build" class="node-title">${expandedNode==='build'?'Collapse settings':'Expand settings'}</button>${settings('build','<p>Existing graph semantics and deterministic validation.</p>')}</article><div class="outside"><span>Outside the pipeline</span><b>Evaluate this run</b><small>Deterministic · existing evaluator</small></div>`;
  $('draftHelp').textContent=active?'One run is active. You may prepare the next draft; start becomes available after it stops.':locked?'This candidate is frozen. Use Edit draft in the review to change it.':calls(config)>store.taskAllowance-store.taskUsed?'Simulated task allowance exhausted. No additional run is authorized.':'';
}
function openReview() {
  if($('run').disabled)return;
  current().plan={stage:'review',snapshot:snapshotRun(current(),current().draft),continuation:false};persist();renderDraft();renderExecution();
  announce('Review the next run. Nothing has been frozen, authorized or started.');
  $('execution').scrollIntoView({block:'nearest'});
  $('freeze')?.focus({preventScroll:true});
}
function reviewMarkup(plan) {
  const run=plan.snapshot,paid=calls(run.config),remaining=store.taskAllowance-store.taskUsed;
  const continuing=plan.continuation,required=continuing?Math.max(0,paid-run.attempts):paid;
  const frozen=plan.stage!=='review', authorized=plan.stage==='authorized';
  return `<div class="review-box"><div class="review-top"><div><h2>${continuing?'Review continuation':frozen?'Frozen run plan':'Review next run'} · ${runName(run)}</h2><p>${inputLabel(run.config)} · ${strategy(run.config)}</p></div><button id="editCandidate">${continuing?'Close review':'Edit draft'}</button></div><ol class="step-list"><li class="${!frozen?'current':''}">Review</li><li class="${plan.stage==='frozen'?'current':''}">Freeze</li><li class="${plan.stage==='frozen'&&required?'current':''}">${required?'Authorize':'No paid authorization required'}</li><li class="${authorized?'current':''}">Start</li></ol><div class="review-summary"><div><dl><dt>Experiment</dt><dd>${escapeHtml(current().name)}</dd><dt>Input identity</dt><dd>${escapeHtml(run.inputId)}${run.config.mode==='fresh'?' · fresh per-run identity (simulated)':''}</dd><dt>Extraction / resolver calls</dt><dd>${Number(run.config.mode==='fresh')} / ${Number(run.config.resolver)}</dd><dt>${continuing?'Remaining invocation bound':'Invocation bound'}</dt><dd>${required} provider call${required===1?'':'s'}</dd><dt>Scored observations</dt><dd>1 for this selected input</dd></dl><p>${run.config.mode==='saved'?'The same frozen extraction allows a matched-input comparison.':'Fresh extraction creates a distinct input. Do not interpret differences as the resolver effect alone.'}</p></div><div><dl><dt>Shared task allowance · simulated</dt><dd>${store.taskAllowance}</dd><dt>Attempts already used</dt><dd>${store.taskUsed}</dd><dt>Remaining allowance</dt><dd>${remaining}</dd><dt>Uncertain in this run</dt><dd>${run.uncertain}</dd><dt>New cost estimate</dt><dd>Unavailable before execution</dd></dl><p>A call bound is not a dollar cap. Creating a run or an experiment does not reset task spending.</p>${frozen?`<p>Frozen plan identity (simulated)<br><code>${run.planDigest}</code></p>`:''}</div></div>${continuing?'<div class="notice">Explicit continuation of the same frozen run. Completed attempts are retained; uncertain attempts are never automatically retried.</div>':''}${plan.stage==='frozen'&&required>0?`<label class="consent"><input id="consent" type="checkbox">Authorize up to ${required} additional provider call${required===1?'':'s'} for this frozen run within the remaining task allowance.</label>`:''}<div class="execution-actions">${plan.stage==='review'?'<button class="primary" id="freeze">Freeze run plan</button><span>Freezing creates no execution authority.</span>':''}${plan.stage==='frozen'&&required>0?'<button class="primary" id="authorize" disabled>Authorize bounded execution</button>':''}${authorized?`<button class="primary" id="start">${continuing?'Start continuation':'Start run'}</button><span>${required?'Authorized · not started':'No provider calls · ready to start'}</span>`:''}</div></div>`;
}
function renderExecution() {
  const experiment=current(),active=experiment.runs.find(r=>['running','stopping'].includes(r.status)),stopped=experiment.runs.find(r=>['stopped','interrupted'].includes(r.status));
  let html=experiment.plan?reviewMarkup(experiment.plan):'';
  if(active)html+=`<div class="run-banner"><div><b>${runName(active)} · ${active.status==='running'?'Running':'Stopping after current attempt'}</b><p>${strategy(active.config)} · ${inputLabel(active.config)}<br>0 / 1 scored observations · no F1 plotted yet</p><p>Future backend execution survives browser navigation. This demo advances only through the simulation controls.</p></div><div class="execution-actions">${active.status==='running'?'<button id="stop">Stop after current attempt</button><button id="finish">Simulate scored result</button>':'<button id="acknowledgeStop">Simulate stop acknowledgement</button>'}</div></div>`;
  if(stopped&&!experiment.plan)html+=`<div class="review-box"><h2>${runName(stopped)} · ${stopped.status}</h2><p>Frozen configuration and completed attempts retained. No continuation occurred.</p><details><summary>Attempt record</summary><p>${stopped.attempts} attempted provider calls · ${stopped.uncertain} uncertain. Score and unresolved costs are unavailable.</p></details><button id="continue" data-id="${stopped.id}">Review continuation</button></div>`;
  $('execution').innerHTML=html;
  $('consent')?.addEventListener('change',()=>{$('authorize').disabled=!$('consent').checked;});
}
function freezePlan() {
  const plan=current().plan;if(!plan||plan.stage!=='review')return;
  plan.stage=calls(plan.snapshot.config)?'frozen':'authorized';persist();renderDraft();renderExecution();
  announce('Run plan frozen. Previous runs are unchanged.');
  (calls(plan.snapshot.config)?$('consent'):$('start'))?.focus();
}
function authorizePlan() {
  const plan=current().plan;if(!plan||plan.stage!=='frozen'||!$('consent')?.checked)return;
  plan.snapshot.authorization=true;plan.stage='authorized';persist();renderExecution();$('start').focus();
}
function startRun() {
  const experiment=current(),plan=experiment.plan;if(!plan||plan.stage!=='authorized'||activeRun())return;
  const run=plan.continuation?experiment.runs.find(r=>r.id===plan.snapshot.id):clone(plan.snapshot);
  const remainingCalls=Math.max(0,calls(run.config)-run.attempts);
  if(remainingCalls>store.taskAllowance-store.taskUsed)return;
  if(!plan.continuation)experiment.runs.push(run);
  run.status='running';run.authorization=plan.snapshot.authorization;
  // Demo accounting represents attempts dispatched at start; real authority remains a future backend concern.
  store.taskUsed+=remainingCalls;run.attempts+=remainingCalls;
  experiment.plan=null;persist();render();announce(`${runName(run)} started in this experiment (simulation). Existing results remain available.`);
  $('finish')?.focus({preventScroll:true});
}
function finishRun() {
  const run=current().runs.find(r=>r.status==='running');if(!run)return;
  run.status='completed';run.completedAt=new Date().toISOString();current().selected=run.id;outcome='matched';relationship=null;
  persist();render();announce(`${runName(run)} added to this experiment’s chart. Configure the next run above; all earlier runs remain intact.`);$('run').focus({preventScroll:true});
}
function renderChart() {
  const runs=visibleRuns(),scored=runs.filter(r=>r.status==='completed');
  const plotted=scored.filter(r=>fixtureObservation(r)?.evaluation?.f1!=null&&(view==='run'||runCosts(r)[costBasis]!=null));
  $('byRun').setAttribute('aria-selected',view==='run');$('byCost').setAttribute('aria-selected',view==='cost');$('costControl').hidden=view!=='cost';
  $('runCount').textContent=`${current().runs.length} run${current().runs.length===1?'':'s'} retained`;
  const maxX=view==='run'?Math.max(3,...current().runs.map(r=>r.number)):Math.max(.0001,...plotted.map(r=>runCosts(r)[costBasis]))*1.1;
  const coords=r=>({x:view==='run'?12+(r.number-1)/Math.max(1,maxX-1)*76:9+runCosts(r)[costBasis]/maxX*82,y:8+fixtureObservation(r).evaluation.f1*82});
  const groups=new Map();plotted.forEach(r=>{const c=coords(r),key=`${c.x.toFixed(5)}:${c.y.toFixed(5)}`;if(!groups.has(key))groups.set(key,[]);groups.get(key).push(r);});
  const points=[...groups.values()].map(group=>{const r=group.find(r=>r.id===current().selected)||group[0],c=coords(r),selected=group.some(r=>r.id===current().selected);return `<button class="point ${r.config.resolver?'':'baseline'}" style="left:${c.x}%;bottom:${c.y}%" data-point="${group.map(r=>r.id).join('|')}" aria-pressed="${selected}" aria-label="${runName(r)}, ${strategy(r.config)}, ${inputLabel(r.config)}, F1 ${fmt(fixtureObservation(r).evaluation.f1)}${group.length>1?`, ${group.length} coincident runs, activate to cycle`:''}"><span class="point-tip">${runName(r)} · ${strategy(r.config)}<br>F1 ${fmt(fixtureObservation(r).evaluation.f1)}${view==='cost'?'<br>'+dollars(runCosts(r)[costBasis]):''}${group.length>1?'<br>'+group.length+' overlapping runs · click to cycle':''}</span></button>`;}).join('');
  const tickValues=view==='run'?Array.from({length:Math.min(maxX,7)},(_,i)=>maxX<=7?i+1:Math.round(1+i*(maxX-1)/6)):[0,maxX/3,maxX*2/3,maxX];
  $('chart').innerHTML=plotted.length?`<div class="axis-title">F1 score · 0–1</div><div class="plot" role="group" aria-label="Experiment run history">${[0,.25,.5,.75,1].map(n=>`<div class="gridline" style="bottom:${8+n*82}%"><span>${n.toFixed(2)}</span></div>`).join('')}${points}</div><div class="xaxis">${tickValues.map(n=>`<span style="left:${view==='run'?12+(n-1)/(maxX-1)*76:9+n/maxX*82}%">${view==='run'?n:n.toFixed(5)}</span>`).join('')}<p>${view==='run'?'Run number within this experiment':'Estimated provider cost · USD'}</p></div>`:`<div class="plot-empty"><div class="new-empty"><h3>${scored.length?'No known costs in this view':'The first scored run appears here'}</h3><p>${scored.length?'Original extraction cost is unavailable for these saved inputs. Choose this run’s provider cost to inspect new spend.':'Configure the pipeline above, then choose Run. Completed runs accumulate here without replacing earlier results.'}</p></div></div>`;
  const unknownScore=runs.filter(r=>r.status==='completed'&&fixtureObservation(r)?.evaluation?.f1==null).length;
  const unknownCost=view==='cost'?scored.filter(r=>runCosts(r)[costBasis]==null).length:0;
  $('coverage').innerHTML=`${plotted.length} / ${runs.length} run${runs.length===1?'':'s'} plotted · ${runs.length-scored.length} awaiting score · ${unknownScore} unavailable F1 · ${unknownCost} unknown cost excluded<br>${view==='run'?'Discrete runs; no connecting lines across different configurations or inputs. No-resolver runs supply the comparison baseline.':costBasis==='runCost'?'Cost of provider calls for this run: saved extraction adds no new extraction spend. Zero is only shown for known zero calls.':'Full pipeline includes original extraction plus resolution. Unknown original extraction cost is excluded, not zero.'}`;
  $('runStrip').innerHTML=runs.map(r=>`<button data-run="${r.id}" aria-pressed="${r.id===current().selected}">${runName(r)} · ${strategy(r.config)}<small>${r.status==='completed'?'F1 '+fmt(fixtureObservation(r).evaluation.f1):r.status+' · F1 unavailable'}</small><small>${inputLabel(r.config)}</small></button>`).join('');
}
function renderInspection() {
  const run=selectedRun();
  if(!run){$('inspection').innerHTML='<h2>Selected-run evaluation</h2><p>Select a completed point to inspect its frozen pipeline, evaluation and exact Evidence.</p>';return;}
  const sample=fixtureFor(run.config,run.freshIndex),observation=fixtureObservation(run),evaluation=run.status==='completed'?observation.evaluation:null,cost=runCosts(run);
  const relations=evaluation?observation.relationships.filter(r=>r.outcome===outcome):[],rel=relations.find(r=>r.id===relationship);
  $('inspection').innerHTML=`<div class="inspection-title"><div><h2>${runName(run)} · ${strategy(run.config)}</h2><p>${inputLabel(run.config)} · ${run.status}</p></div><span class="badge">${evaluation?'F1 '+fmt(evaluation.f1):'F1 unavailable'}</span></div>${run.config.mode==='fresh'?'<p class="comparison-caution">Fresh extraction: this run has a different input identity. A quality change may reflect extraction as well as configuration.</p>':''}<div class="frozen-info"><div class="frozen-header"><h3>Frozen pipeline for ${runName(run)}</h3><button id="copyDraft" ${current().plan?'disabled':''}>Use as next draft</button></div><div class="frozen-route"><span>${run.config.mode==='saved'?'Saved extraction':'Fresh extraction'}</span>${arrow}<span>${strategy(run.config)}</span>${arrow}<span>Build graph</span>${arrow}<span>Evaluate</span></div><details ${showRecord?'open':''}><summary>Configuration, input identities & execution record</summary><dl><dt>Model</dt><dd>${run.config.model}</dd><dt>Provider settings</dt><dd>Retained default settings · no changed-model claim</dd><dt>Input artifact</dt><dd>${run.inputId}</dd><dt>Input instance</dt><dd>${run.config.mode==='saved'?'Shared frozen extraction':'New per-run extraction (simulated)'}</dd><dt>Extraction digest</dt><dd><code>${escapeHtml(run.inputDigest||'Unavailable')}</code></dd><dt>Source digest</dt><dd><code>${escapeHtml(run.sourceDigest||'Unavailable')}</code></dd><dt>Code revision</dt><dd><code>${run.code}</code></dd><dt>Plan identity</dt><dd><code>${run.planDigest} · simulated</code></dd><dt>Provider attempts / uncertain</dt><dd>${run.attempts} / ${run.uncertain}</dd><dt>This run’s provider cost</dt><dd>${evaluation?dollars(cost.runCost):'Unavailable'}</dd><dt>Full-pipeline cost</dt><dd>${evaluation?dollars(cost.fullCost):'Unavailable'}</dd><dt>Pricing provenance</dt><dd>Issue #92 frozen pricing · estimate</dd><dt>Outcome reference</dt><dd>${sample.id} / ${observation.id}</dd></dl><p>Run ${run.seeded?'01 maps a retained baseline into this illustrative workspace':'execution and chronology are simulated; outcome reused from the retained observation'}. No new quality or cost measurement is claimed.</p></details></div>${evaluation?`<div class="metric-line"><span>Precision<b>${fmt(evaluation.precision)}</b></span><span>Recall<b>${fmt(evaluation.recall)}</b></span><span>F1<b>${fmt(evaluation.f1)}</b></span><span>Provenance accuracy<b>${fmt(evaluation.provenance_accuracy)}</b></span></div><div class="matrix" aria-label="Selected run relationship matrix">${[['matched','Matched','TP','tp'],['extra','Extra','FP','fp'],['missing','Missing','FN','fn']].map(([key,title,abbr,metric])=>`<button data-outcome="${key}" aria-pressed="${outcome===key}"><span>${title}<small>${abbr} relationships</small></span><b>${evaluation[metric]}</b></button>`).join('')}</div><div class="investigation"><div class="relationships"><h3>${outcome[0].toUpperCase()+outcome.slice(1)} relationships</h3>${relations.length?relations.map(r=>`<button data-relation="${r.id}" aria-pressed="${r.id===relationship}">${escapeHtml(r.edge[0])}<b>${escapeHtml(r.edge[1].replaceAll('_',' '))}</b>${escapeHtml(r.edge[2])}</button>`).join(''):'<p>No recorded relationships in this category.</p>'}</div><div class="evidence"><h3>Exact Evidence · ${runName(run)}</h3><p>${strategy(run.config)} · ${sample.id}</p>${rel?['expected','predicted'].map(kind=>`<div class="evidence-group"><b>${kind==='expected'?'Expected':'Predicted'} support</b>${rel[kind].length?rel[kind].map((q,i)=>`<blockquote>${escapeHtml(q.text)}</blockquote><button data-quote="${kind}:${i}">View in Source · ${q.occurrences.length} match${q.occurrences.length===1?'':'es'}</button>`).join(''):`<p>${kind==='predicted'&&outcome==='missing'?'No predicted relationship. No predicted Evidence exists.':'No retained '+kind+' Evidence.'}</p>`}</div>`).join(''):'<p>Select an individual relationship to inspect the exact supporting Source.</p>'}<div id="source"></div></div></div>`:'<div class="no-result"><h3>No scored result yet</h3><p>This run remains in history. Its unavailable evaluation and cost are not plotted as zero.</p></div>'}`;
}
function viewSource(kind,index) {
  const run=selectedRun(),sample=fixtureFor(run.config,run.freshIndex),rel=fixtureObservation(run).relationships.find(r=>r.id===relationship),quote=rel[kind][index];
  const chars=Array.from(sample.source);let html='',cursor=0;
  for(const [start,end] of quote.occurrences){html+=escapeHtml(chars.slice(cursor,start).join(''))+'<mark>'+escapeHtml(chars.slice(start,end).join(''))+'</mark>';cursor=end;}
  html+=escapeHtml(chars.slice(cursor).join(''));
  $('source').innerHTML=`<h3>Frozen Source · ${runName(run)}</h3><p class="source-id">${quote.source_id} · ${quote.occurrences.length} exact occurrence(s)</p><article class="source" tabindex="0" aria-label="Frozen Source with exact Evidence">${html}</article>`;
  const article=$('source').querySelector('article'),mark=article.querySelector('mark');article.scrollTop=mark.offsetTop-70;
}
function render() { renderHistory();renderDraft();renderExecution();renderChart();renderInspection(); }
$('run').onclick=openReview;
$('benchmark').onchange=e=>editDraft({input:e.target.value});
$('inputMode').onchange=e=>editDraft({mode:e.target.value});
$('byRun').onclick=()=>{view='run';renderChart();};$('byCost').onclick=()=>{view='cost';renderChart();};
$('costBasis').onchange=e=>{costBasis=e.target.value;renderChart();};$('filter').onchange=e=>{filter=e.target.value;renderChart();};
$('openHistory').onclick=()=>$('history').classList.add('open');$('closeHistory').onclick=()=>$('history').classList.remove('open');
$('pan').onclick=()=>{const c=document.querySelector('.canvas');c.scrollLeft=c.scrollLeft?0:c.scrollWidth;};
$('search').oninput=e=>document.querySelectorAll('[data-experiment]').forEach(el=>el.hidden=!el.textContent.toLowerCase().includes(e.target.value.toLowerCase()));
function nameDialog(rename) {renameMode=rename;$('nameTitle').textContent=rename?'Rename experiment':'New experiment';$('nameInput').value=rename?current().name:'';$('nameDialog').showModal();$('nameInput').focus();}
$('newExperiment').onclick=()=>nameDialog(false);$('rename').onclick=()=>nameDialog(true);$('cancelName').onclick=()=>$('nameDialog').close();
$('nameForm').onsubmit=e=>{e.preventDefault();const name=$('nameInput').value.trim();if(!name)return;if(renameMode)current().name=name;else{const experiment=newWorkspace(name);store.experiments.push(experiment);store.current=experiment.id;}persist();$('nameDialog').close();$('history').classList.remove('open');render();};
$('reset').onclick=()=>{store=initialStore();view='run';filter='all';$('filter').value='all';outcome='matched';relationship=null;persist();render();announce('Demo reset. This affects illustrative browser data only.');};
document.addEventListener('keydown',event=>{if(event.target.matches('[role=tab]')&&['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();view=view==='run'?'cost':'run';renderChart();$(view==='run'?'byRun':'byCost').focus();}});
document.addEventListener('click',event=>{
  const button=event.target.closest('button');if(!button||button.disabled)return;
  if(button.id==='addResolver'){editDraft({resolver:true});$('removeResolver')?.focus({preventScroll:true});}
  if(button.id==='removeResolver'){editDraft({resolver:false});$('addResolver')?.focus({preventScroll:true});}
  if(button.dataset.settings){expandedNode=expandedNode===button.dataset.settings?null:button.dataset.settings;renderDraft();restoreFocus('data-settings',button.dataset.settings);}
  if(button.id==='freeze')freezePlan();if(button.id==='authorize')authorizePlan();if(button.id==='start')startRun();if(button.id==='finish')finishRun();
  if(button.id==='editCandidate'){current().plan=null;persist();renderDraft();renderExecution();$('run').focus();announce('Returned to draft. Prior candidate authorization is invalidated; previous runs remain unchanged.');}
  if(button.id==='stop'){activeRun().status='stopping';persist();render();$('acknowledgeStop')?.focus();}
  if(button.id==='acknowledgeStop'){const run=activeRun();run.status='stopped';persist();render();announce('Run stopped. Use explicit continuation to inspect its remaining work.');}
  if(button.id==='continue'){const run=current().runs.find(r=>r.id===button.dataset.id);current().plan={stage:'authorized',snapshot:clone(run),continuation:true};persist();renderDraft();renderExecution();}
  if(button.id==='copyDraft'){current().draft=clone(selectedRun().config);persist();renderDraft();announce(`${runName(selectedRun())} configuration copied into the next-run draft. No result or authorization was copied.`);$('run').focus({preventScroll:true});}
  if(button.dataset.experiment){store.current=button.dataset.experiment;outcome='matched';relationship=null;persist();$('history').classList.remove('open');render();}
  if(button.dataset.run){selectRun(button.dataset.run);restoreFocus('data-run',button.dataset.run);}
  if(button.dataset.point){const ids=button.dataset.point.split('|'),index=ids.indexOf(current().selected);selectRun(ids[(index+1)%ids.length]);restoreFocus('data-point',button.dataset.point);}
  if(button.dataset.outcome){outcome=button.dataset.outcome;relationship=null;renderInspection();restoreFocus('data-outcome',button.dataset.outcome);}
  if(button.dataset.relation){relationship=button.dataset.relation;renderInspection();restoreFocus('data-relation',button.dataset.relation);}
  if(button.dataset.quote){const [kind,index]=button.dataset.quote.split(':');viewSource(kind,+index);}
});
persist();render();
