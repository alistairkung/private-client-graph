# Execution and Evaluation: three design approaches

Design exploration only. Pipeline HTML/CSS/interaction is copied unchanged from the approved inline-nodes exploration. No production code, experiment execution or provider calls.

A — Control strip: execution reads across a compact strip; a full-width outcome matrix sits above an integrated relationship/Evidence inspector. Lowest learning cost; most vertical scrolling.
B — Comparison bench: execution authority/status is an anchor on the left. Outcome matrix and metrics remain beside the relationship/Evidence inspector on desktop, allowing comparison while reading support. Recommended for the core evaluation task; has less room for long relationship lists.
C — Observation desk: execution is a ledger, and repetitions become a persistent observation navigator next to the inspector. Best for repeated review across observations; denser than A.

Pre-execution and completed Issue92 buttons switch each design between the requested states. Top scenario selector additionally exposes frozen, authorization, authorized-not-started, running, stopped, interrupted and failed examples. Everything is simulated except retained historical content. Freezing never grants authorization. Explicit unchecked consent previews authorization; starting is a separate action. Stop is labelled after-current-attempt; continuation requires review and renewed explicit authorization in this exploration. This does not prescribe a new backend permission model.

Retained Issue92: 5 extraction calls, 33 resolver calls, 44 scored observations; 38 valid attempts, 0 provider failures, 0 uncertain. Input tokens70307, output3449, mean provider latency0.918921648s over38 attempts. Estimated spendUSD0.004279962 from retained pricing; not an invoice. No unknown telemetry is synthesized. Live-layout counters and authority are explicitly examples.

Evaluation metrics and Evidence come from retained projections. Case03 baseline TP6/FP1/FN1, treatment7/0/0. Three recorded treatment repetitions preserve variability, not an average invented in the UI. Matrix scoped to selected input/repetition. No TN universe. Partial states show a clearly identified subset of retained examples, never final aggregate scores or results of the simulated execution.

Selecting an outcome opens relationship choices. Selecting a relationship opens expected/predicted support; quote buttons locate exact Unicode offsets in frozen Source. Provider usage is behind disclosure. Historical imports have no execution controls. Layouts checked at1600px and390px, with authorization and exact-Evidence interactions exercised across all three.
